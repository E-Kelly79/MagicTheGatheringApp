# Magic The Garthering
|Name            |Student No||
|----------------|----------|-|
|Eoin Kelly		 | 20074820|

 About App
This app was an assignment from collage. It will let you search for cards by name color and type it will also let you add cards to decks and even make new decks and delete cards from decks it will also have some of the game tools like dice rolls and life counters
![Card List ](https://ibb.co/mTZZF7)

![Search Screen](https://ibb.co/hhKehn)

![Single card information screen](https://ibb.co/hcuZF7)


# Persistence
The persistence i took on this is was to use fire base but for the first part of the project i used shared preferences that when you searched for a card and killed the app it would open up on your last search but with fire base this will be a lot more useful as you will be able to save your decks and search's


## Github

Github was used to build up the version of the app after each version was created the project got uploaded to github [https://github.com/E-Kelly79/MagicTheGartheringApp](https://github.com/E-Kelly79/MagicTheGartheringApp)

## UX/DX



## References
